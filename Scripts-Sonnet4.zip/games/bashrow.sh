#!/bin/bash

# BashRow - A Complete Tetris Game in Bash
# Version 1.0

set -e

# Game configuration
GAME_NAME="BashRow"
GAME_VERSION="1.0"
DEFAULT_DELAY=1000
DEMO_TIMEOUT=30
BOARD_WIDTH=10
BOARD_HEIGHT=20
PREVIEW_SIZE=4

# Colors using ANSI escape codes
declare -A COLORS=(
    [0]="\033[0m"      # Reset
    [1]="\033[41m"     # Red (I-piece)
    [2]="\033[42m"     # Green (O-piece)
    [3]="\033[43m"     # Yellow (T-piece)
    [4]="\033[44m"     # Blue (S-piece)
    [5]="\033[45m"     # Magenta (Z-piece)
    [6]="\033[46m"     # Cyan (J-piece)
    [7]="\033[47m"     # White (L-piece)
    [8]="\033[40m"     # Black (empty)
)

# Tetromino shapes (4x4 grids, 0=empty, 1-7=colored blocks)
declare -A PIECES=(
    # I-piece (Red)
    [I]="0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0"
    # O-piece (Green)
    [O]="0,0,0,0,0,2,2,0,0,2,2,0,0,0,0,0"
    # T-piece (Yellow)
    [T]="0,0,0,0,0,3,0,0,3,3,3,0,0,0,0,0"
    # S-piece (Blue)
    [S]="0,0,0,0,0,4,4,0,4,4,0,0,0,0,0,0"
    # Z-piece (Magenta)
    [Z]="0,0,0,0,5,5,0,0,0,5,5,0,0,0,0,0"
    # J-piece (Cyan)
    [J]="0,0,0,0,6,0,0,0,6,6,6,0,0,0,0,0"
    # L-piece (White)
    [L]="0,0,0,0,0,0,7,0,7,7,7,0,0,0,0,0"
)

# Game state variables
declare -a BOARD
declare -a CURRENT_PIECE
declare -a NEXT_PIECE
CURRENT_X=0
CURRENT_Y=0
CURRENT_ROTATION=0
SCORE=0
LINES_CLEARED=0
LEVEL=1
DROP_DELAY=$DEFAULT_DELAY
DEMO_MODE=true
DEMO_START_TIME=0
GAME_OVER=false
PAUSED=false

# Terminal dimensions
TERM_WIDTH=0
TERM_HEIGHT=0

# Initialize the game board
init_board() {
    BOARD=()
    for ((i = 0; i < BOARD_WIDTH * BOARD_HEIGHT; i++)); do
        BOARD[i]=0
    done
}

# Get board cell value
get_board() {
    local x=$1 y=$2
    if [[ $x -lt 0 || $x -ge $BOARD_WIDTH || $y -lt 0 || $y -ge $BOARD_HEIGHT ]]; then
        echo 1  # Treat out-of-bounds as solid
    else
        echo ${BOARD[$((y * BOARD_WIDTH + x))]}
    fi
}

# Set board cell value
set_board() {
    local x=$1 y=$2 value=$3
    if [[ $x -ge 0 && $x -lt $BOARD_WIDTH && $y -ge 0 && $y -lt $BOARD_HEIGHT ]]; then
        BOARD[$((y * BOARD_WIDTH + x))]=$value
    fi
}

# Get piece cell value (4x4 grid)
get_piece() {
    local piece_name=$1 rotation=$2 x=$3 y=$4
    local piece_data=${PIECES[$piece_name]}
    IFS=',' read -ra piece_array <<< "$piece_data"
    
    # Apply rotation
    local rx ry
    case $rotation in
        0) rx=$x; ry=$y ;;
        1) rx=$((3-y)); ry=$x ;;
        2) rx=$((3-x)); ry=$((3-y)) ;;
        3) rx=$y; ry=$((3-x)) ;;
    esac
    
    if [[ $rx -ge 0 && $rx -lt 4 && $ry -ge 0 && $ry -lt 4 ]]; then
        echo ${piece_array[$((ry * 4 + rx))]}
    else
        echo 0
    fi
}

# Check if piece can be placed at position
can_place_piece() {
    local piece_name=$1 rotation=$2 px=$3 py=$4
    
    for ((y = 0; y < 4; y++)); do
        for ((x = 0; x < 4; x++)); do
            local piece_cell=$(get_piece "$piece_name" "$rotation" "$x" "$y")
            if [[ $piece_cell -ne 0 ]]; then
                local board_x=$((px + x))
                local board_y=$((py + y))
                local board_cell=$(get_board "$board_x" "$board_y")
                if [[ $board_cell -ne 0 ]]; then
                    return 1  # Cannot place
                fi
            fi
        done
    done
    return 0  # Can place
}

# Place piece on board
place_piece() {
    local piece_name=$1 rotation=$2 px=$3 py=$4
    
    for ((y = 0; y < 4; y++)); do
        for ((x = 0; x < 4; x++)); do
            local piece_cell=$(get_piece "$piece_name" "$rotation" "$x" "$y")
            if [[ $piece_cell -ne 0 ]]; then
                local board_x=$((px + x))
                local board_y=$((py + y))
                set_board "$board_x" "$board_y" "$piece_cell"
            fi
        done
    done
}

# Generate random piece
random_piece() {
    local pieces=(I O T S Z J L)
    echo ${pieces[$((RANDOM % 7))]}
}

# Initialize new piece
new_piece() {
    CURRENT_PIECE[0]=$(random_piece)
    CURRENT_X=$((BOARD_WIDTH / 2 - 2))
    CURRENT_Y=0
    CURRENT_ROTATION=0
    
    # Generate next piece if not set
    if [[ -z ${NEXT_PIECE[0]} ]]; then
        NEXT_PIECE[0]=$(random_piece)
    fi
    
    # Check game over
    if ! can_place_piece "${CURRENT_PIECE[0]}" "$CURRENT_ROTATION" "$CURRENT_X" "$CURRENT_Y"; then
        GAME_OVER=true
    fi
}

# Clear completed lines
clear_lines() {
    local lines_to_clear=()
    
    # Find completed lines
    for ((y = 0; y < BOARD_HEIGHT; y++)); do
        local complete=true
        for ((x = 0; x < BOARD_WIDTH; x++)); do
            if [[ $(get_board "$x" "$y") -eq 0 ]]; then
                complete=false
                break
            fi
        done
        if $complete; then
            lines_to_clear+=($y)
        fi
    done
    
    # Clear lines and update score
    local cleared=${#lines_to_clear[@]}
    if [[ $cleared -gt 0 ]]; then
        # Remove cleared lines
        for line in "${lines_to_clear[@]}"; do
            for ((y = line; y > 0; y--)); do
                for ((x = 0; x < BOARD_WIDTH; x++)); do
                    set_board "$x" "$y" "$(get_board "$x" "$((y-1))")"
                done
            done
            # Clear top line
            for ((x = 0; x < BOARD_WIDTH; x++)); do
                set_board "$x" 0 0
            done
        done
        
        # Update score
        LINES_CLEARED=$((LINES_CLEARED + cleared))
        case $cleared in
            1) SCORE=$((SCORE + 40 * LEVEL)) ;;
            2) SCORE=$((SCORE + 100 * LEVEL)) ;;
            3) SCORE=$((SCORE + 300 * LEVEL)) ;;
            4) SCORE=$((SCORE + 1200 * LEVEL)) ;;
        esac
        
        # Update level
        LEVEL=$(((LINES_CLEARED / 10) + 1))
        DROP_DELAY=$((DEFAULT_DELAY - (LEVEL - 1) * 50))
        if [[ $DROP_DELAY -lt 100 ]]; then
            DROP_DELAY=100
        fi
    fi
}

# Get terminal dimensions
get_terminal_size() {
    TERM_WIDTH=$(tput cols)
    TERM_HEIGHT=$(tput lines)
}

# Clear screen and hide cursor
init_display() {
    clear
    tput civis  # Hide cursor
    stty -echo  # Disable echo
}

# Restore terminal
cleanup_display() {
    tput cnorm  # Show cursor
    stty echo   # Enable echo
    clear
}

# Draw a colored block
draw_block() {
    local color=$1
    printf "${COLORS[$color]}  ${COLORS[0]}"
}

# Draw the game board
draw_board() {
    local start_x=$((TERM_WIDTH - BOARD_WIDTH * 2 - 2))
    local start_y=2
    
    # Draw board border
    tput cup $((start_y - 1)) $((start_x - 1))
    printf "+"
    for ((i = 0; i < BOARD_WIDTH * 2; i++)); do
        printf "-"
    done
    printf "+"
    
    # Draw board content
    for ((y = 0; y < BOARD_HEIGHT; y++)); do
        tput cup $((start_y + y)) $((start_x - 1))
        printf "|"
        for ((x = 0; x < BOARD_WIDTH; x++)); do
            local cell=$(get_board "$x" "$y")
            
            # Check if current piece occupies this cell
            local piece_here=false
            if [[ -n ${CURRENT_PIECE[0]} ]]; then
                for ((py = 0; py < 4; py++)); do
                    for ((px = 0; px < 4; px++)); do
                        local piece_cell=$(get_piece "${CURRENT_PIECE[0]}" "$CURRENT_ROTATION" "$px" "$py")
                        if [[ $piece_cell -ne 0 && $((CURRENT_X + px)) -eq $x && $((CURRENT_Y + py)) -eq $y ]]; then
                            cell=$piece_cell
                            piece_here=true
                            break 2
                        fi
                    done
                done
            fi
            
            draw_block "$cell"
        done
        printf "|"
    done
    
    # Draw bottom border
    tput cup $((start_y + BOARD_HEIGHT)) $((start_x - 1))
    printf "+"
    for ((i = 0; i < BOARD_WIDTH * 2; i++)); do
        printf "-"
    done
    printf "+"
}

# Draw the info panel
draw_info() {
    local start_x=2
    local start_y=2
    
    # Game title and version
    tput cup $start_y $start_x
    printf "\033[1m%s v%s\033[0m" "$GAME_NAME" "$GAME_VERSION"
    
    # Score
    tput cup $((start_y + 2)) $start_x
    printf "Score: %d" "$SCORE"
    
    # Lines
    tput cup $((start_y + 3)) $start_x
    printf "Lines: %d" "$LINES_CLEARED"
    
    # Level
    tput cup $((start_y + 4)) $start_x
    printf "Level: %d" "$LEVEL"
    
    # Next piece
    tput cup $((start_y + 6)) $start_x
    printf "Next:"
    if [[ -n ${NEXT_PIECE[0]} ]]; then
        for ((y = 0; y < 4; y++)); do
            tput cup $((start_y + 7 + y)) $start_x
            for ((x = 0; x < 4; x++)); do
                local cell=$(get_piece "${NEXT_PIECE[0]}" 0 "$x" "$y")
                draw_block "$cell"
            done
        done
    fi
    
    # Demo mode indicator
    if $DEMO_MODE; then
        tput cup $((start_y + 12)) $start_x
        printf "\033[33mDEMO MODE\033[0m"
        tput cup $((start_y + 13)) $start_x
        printf "Press any key to play"
    fi
    
    # Controls
    tput cup $((start_y + 15)) $start_x
    printf "Controls:"
    tput cup $((start_y + 16)) $start_x
    printf "A/D - Move"
    tput cup $((start_y + 17)) $start_x
    printf "S - Soft drop"
    tput cup $((start_y + 18)) $start_x
    printf "Space - Rotate"
    tput cup $((start_y + 19)) $start_x
    printf "Down - Hard drop"
    tput cup $((start_y + 20)) $start_x
    printf "Q - Quit"
}

# Draw everything
draw_screen() {
    get_terminal_size
    draw_board
    draw_info
}

# Move piece
move_piece() {
    local dx=$1 dy=$2
    local new_x=$((CURRENT_X + dx))
    local new_y=$((CURRENT_Y + dy))
    
    if can_place_piece "${CURRENT_PIECE[0]}" "$CURRENT_ROTATION" "$new_x" "$new_y"; then
        CURRENT_X=$new_x
        CURRENT_Y=$new_y
        return 0
    fi
    return 1
}

# Rotate piece
rotate_piece() {
    local new_rotation=$(((CURRENT_ROTATION + 1) % 4))
    
    if can_place_piece "${CURRENT_PIECE[0]}" "$new_rotation" "$CURRENT_X" "$CURRENT_Y"; then
        CURRENT_ROTATION=$new_rotation
        return 0
    fi
    return 1
}

# Hard drop piece
hard_drop() {
    while move_piece 0 1; do
        SCORE=$((SCORE + 2))
    done
}

# Demo AI - simple strategy
demo_ai() {
    local action=$((RANDOM % 10))
    
    case $action in
        0|1) move_piece -1 0 ;;  # Move left
        2|3) move_piece 1 0 ;;   # Move right
        4) rotate_piece ;;       # Rotate
        5) hard_drop ;;          # Hard drop occasionally
        *) ;;                    # Do nothing
    esac
}

# Handle input
handle_input() {
    local key
    if read -t 0.1 -n 1 key 2>/dev/null; then
        if $DEMO_MODE; then
            DEMO_MODE=false
        fi
        
        case $key in
            'a'|'A') move_piece -1 0 ;;
            'd'|'D') move_piece 1 0 ;;
            's'|'S') move_piece 0 1 ;;
            ' ') rotate_piece ;;
            $'\e') # Escape sequence
                read -t 0.1 -n 1 key
                if [[ $key == '[' ]]; then
                    read -t 0.1 -n 1 key
                    case $key in
                        'B') hard_drop ;;  # Down arrow
                    esac
                fi
                ;;
            'q'|'Q') exit 0 ;;
            'p'|'P') PAUSED=$(!PAUSED) ;;
        esac
    fi
}

# Game loop
game_loop() {
    local last_drop=0
    DEMO_START_TIME=$(date +%s)
    
    while ! $GAME_OVER; do
        local current_time=$(date +%s%3N)  # Milliseconds
        
        # Handle demo mode timeout
        if $DEMO_MODE; then
            local elapsed=$(($(date +%s) - DEMO_START_TIME))
            if [[ $elapsed -ge $DEMO_TIMEOUT ]]; then
                break
            fi
        fi
        
        # Handle input
        handle_input
        
        if ! $PAUSED; then
            # Demo AI
            if $DEMO_MODE && [[ $((RANDOM % 5)) -eq 0 ]]; then
                demo_ai
            fi
            
            # Drop piece
            if [[ $((current_time - last_drop)) -ge $DROP_DELAY ]]; then
                if ! move_piece 0 1; then
                    # Piece landed
                    place_piece "${CURRENT_PIECE[0]}" "$CURRENT_ROTATION" "$CURRENT_X" "$CURRENT_Y"
                    clear_lines
                    
                    # Get next piece
                    CURRENT_PIECE[0]=${NEXT_PIECE[0]}
                    NEXT_PIECE[0]=$(random_piece)
                    CURRENT_X=$((BOARD_WIDTH / 2 - 2))
                    CURRENT_Y=0
                    CURRENT_ROTATION=0
                    
                    # Check game over
                    if ! can_place_piece "${CURRENT_PIECE[0]}" "$CURRENT_ROTATION" "$CURRENT_X" "$CURRENT_Y"; then
                        GAME_OVER=true
                    fi
                fi
                last_drop=$current_time
            fi
        fi
        
        # Draw screen
        draw_screen
        
        # Small delay to prevent excessive CPU usage
        sleep 0.02
    done
}

# Parse command line arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --delay)
                DROP_DELAY="$2"
                DEFAULT_DELAY="$2"
                shift 2
                ;;
            --help|-h)
                echo "Usage: $0 [--delay MILLISECONDS]"
                echo "  --delay: Set drop delay in milliseconds (default: 1000)"
                exit 0
                ;;
            *)
                echo "Unknown option: $1"
                exit 1
                ;;
        esac
    done
}

# Main function
main() {
    parse_args "$@"
    
    # Set up signal handlers
    trap cleanup_display EXIT
    trap 'GAME_OVER=true' INT TERM
    
    # Initialize game
    init_board
    init_display
    new_piece
    
    # Start game loop
    game_loop
    
    # Game over screen
    tput cup $((TERM_HEIGHT / 2)) $((TERM_WIDTH / 2 - 10))
    if $DEMO_MODE; then
        printf "\033[33mDemo completed!\033[0m"
    else
        printf "\033[31mGame Over!\033[0m"
    fi
    tput cup $((TERM_HEIGHT / 2 + 1)) $((TERM_WIDTH / 2 - 10))
    printf "Final Score: %d" "$SCORE"
    tput cup $((TERM_HEIGHT / 2 + 2)) $((TERM_WIDTH / 2 - 10))
    printf "Press any key to exit..."
    
    read -n 1
}

# Run the game
main "$@"
